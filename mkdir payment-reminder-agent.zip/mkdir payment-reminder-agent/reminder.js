import Retell from 'retell-sdk';
import fs from 'fs';
import csv from 'csv-parser';
import twilio from 'twilio';

// --- CONFIG ---
const RETELL_API_KEY = 'key_96a38a79fe96a1bf2c73248cf134';
const RETELL_AGENT_ID = 'agent_1f8f735e127893263cac80c7a9';
const RETELL_FROM_NUMBER = '+17756187360';
const CSV_FILE = 'payments.csv';

const TWILIO_ACCOUNT_SID = 'AC7bc37bf8e505721faff3d740de9cbda2';
const TWILIO_AUTH_TOKEN = 'ef89b9e77d6205a8471d2ba4e5f457cd';
const TWILIO_FROM_NUMBER = '+16076002829'; // Twilio SMS number

const retellClient = new Retell({ apiKey: RETELL_API_KEY });
const twilioClient = twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

// Call function
function sendReminderCall({ name, phone, amount, due_date }) {
  return retellClient.call.createPhoneCall({
    from_number: RETELL_FROM_NUMBER,
    to_number: phone,
    agent_id: RETELL_AGENT_ID,
    retell_llm_dynamic_variables: {
      customer_name: name,
      amount_due: amount,
      due_date: due_date
    }
  });
}

// SMS function
function sendReminderSMS({ name, phone, amount, due_date }) {
  const message = `Hello ${name}, this is a reminder that your payment of ₹${amount} is due on ${due_date}.`;
  return twilioClient.messages.create({
    body: message,
    from: TWILIO_FROM_NUMBER,
    to: phone
  });
}

// Read CSV and process
const customers = [];
fs.createReadStream(CSV_FILE)
  .pipe(csv())
  .on('data', (row) => {
    customers.push(row);
  })
  .on('end', async () => {
    console.log(`Total customers to process: ${customers.length}`);
    for (let row of customers) {
      try {
        console.log(`Calling ${row.name} (${row.phone})...`);
        const callRes = await sendReminderCall(row);
        console.log(`✅ Call sent, ID: ${callRes.id || '(see Retell logs)'}`);

        console.log(`Sending SMS to ${row.name} (${row.phone})...`);
        const smsRes = await sendReminderSMS(row);
        console.log(`✅ SMS sent, SID: ${smsRes.sid}`);

      } catch (err) {
        console.error(`❌ Failed for ${row.name} (${row.phone}):`, err.message || err);
      }
    }
    console.log('All reminders processed!');
  });
